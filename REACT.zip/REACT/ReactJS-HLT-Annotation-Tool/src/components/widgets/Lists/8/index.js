import React from 'react'
import style from './style.module.scss'

class List8 extends React.Component {
  render() {
    return (
      <div>
        <ul className="list-unstyled">
          <li className={style.item}>
            <a href="#" className={style.itemLink}>
              <div className={`${style.itemPic} bg-success`}>
                <i className="fe fe-file-text" />
              </div>
              <div className="mr-2">
                <div>Payment Received</div>
                <div className="text-muted">3 minutes ago</div>
              </div>
              <div className={style.itemAction}>
                <span />
              </div>
            </a>
          </li>
          <li className={style.item}>
            <a href="#" className={style.itemLink}>
              <div className={`${style.itemPic} bg-info`}>
                <i className="fe fe-mail" />
              </div>
              <div className="mr-2">
                <div>Message Removed</div>
                <div className="text-muted">2 hours ago</div>
              </div>
              <div className={style.itemAction}>
                <span />
              </div>
            </a>
          </li>
          <li className={style.item}>
            <a href="#" className={style.itemLink}>
              <div className={`${style.itemPic} bg-danger`}>
                <i className="fe fe-grid" />
              </div>
              <div className="mr-2">
                <div>Parcel Received</div>
                <div className="text-muted">6 hours ago</div>
              </div>
              <div className={style.itemAction}>
                <span />
              </div>
            </a>
          </li>
          <li className={style.item}>
            <a href="#" className={style.itemLink}>
              <div className={`${style.itemPic} bg-primary`}>
                <i className="fe fe-database" />
              </div>
              <div className="mr-2">
                <div>Parcel Recived</div>
                <div className="text-muted">15 hours ago</div>
              </div>
              <div className={style.itemAction}>
                <span />
              </div>
            </a>
          </li>
          <li className={style.item}>
            <a href="#" className={style.itemLink}>
              <div className={`${style.itemPic} bg-success`}>
                <i className="fe fe-flag" />
              </div>
              <div className="mr-2">
                <div>User Activated</div>
                <div className="text-muted">2 days ago</div>
              </div>
              <div className={style.itemAction}>
                <span />
              </div>
            </a>
          </li>
        </ul>
      </div>
    )
  }
}

export default List8
